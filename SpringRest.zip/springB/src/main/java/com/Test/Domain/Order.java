package com.Test.Domain;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.*;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "orders")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;

    @OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToMany(cascade = {CascadeType.PERSIST, CascadeType.REMOVE}, fetch = FetchType.EAGER, mappedBy = "order")
    @JsonManagedReference
    private List<Item> items;

    public void setCustomer(Customer cust){this.customer = cust;}
    /*public Order() {

    }

    public Order(long id, Date date , Customer cust, List<Item> items) {
        super();
        this.items=items;
        this.customer=cust;
        this.createdAt=date;
        this.Id=id;
    }*/

}
