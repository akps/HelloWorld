package com.Test.Domain.Repository;

import com.Test.Domain.Customer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
@Qualifier("fakeData")
public interface CustomerRepository extends CrudRepository<Customer,Long> {

    Customer findByName(String name);
}
