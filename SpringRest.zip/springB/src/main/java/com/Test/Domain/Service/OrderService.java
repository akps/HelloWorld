package com.Test.Domain.Service;

import com.Test.Domain.Customer;
import com.Test.Domain.Order;
import com.Test.Domain.Repository.CustomerRepository;
import com.Test.Domain.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    @Autowired
    //@Qualifier("fakeData")
    private OrderRepository orderRepo;

    public List<Order> getAllOrders(long Id){
        List<Order> orders = new ArrayList<>();
        orderRepo.findAll().forEach(orders::add);
        return orders;
    }

    public Optional<Order> getOrderById(long Id){
        return orderRepo.findById(Id);
    }

    public void removeOrderById(long id) {
        this.orderRepo.deleteById(id);
    }

    public void updateOrder(Order order) {
        this.orderRepo.save(order);
    }

    public void addOrder(Order order) {
        orderRepo.save(order);
    }
}
