package com.Test.Domain.Controller;

import com.Test.Domain.Customer;
import com.Test.Domain.Order;
import com.Test.Domain.Service.CustomerService;
import com.Test.Domain.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired CustomerService customerService;

    @RequestMapping("/customers/{customerId}/orders/{id}")
    public Order getAllOrders(@PathVariable long id){
        return orderService.getOrderById(id).orElse(null);
    }

    @RequestMapping("/customers/{customerId}/orders")
    public Optional<Order> getOrder(@PathVariable long id){
        return orderService.getOrderById(id);
    }

    @RequestMapping( method = RequestMethod.POST, value = "/customers/{customerId}/orders")
    public void addOrder(@RequestBody Order order, @PathVariable long customerId){
        order.setCustomer(new Customer(customerId,"Test"));

        orderService.addOrder(order);
    }

    @RequestMapping( method = RequestMethod.PUT, value = "/customers/{customerId}/orders/{id}")
    public void updateOrder(@RequestBody Order order, @PathVariable long customerId, @PathVariable long id){

        //Order ord = orderService.getOrderById(id).orElse(null);
        //ord.setCustomer(new Customer(customerId,"Test"));
        order.setCustomer(new Customer(customerId,"Test"));
        orderService.updateOrder(order);
    }

    @RequestMapping( method = RequestMethod.DELETE, value = "/customers/{customerId}/orders/{id}")
    public void deleteOrder(@PathVariable long id){

        orderService.removeOrderById(id);
    }

}
