package com.Test.Domain.Repository;

import com.Test.Domain.Customer;
import com.Test.Domain.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product,Long> {

    Product findByName(String name);
}
