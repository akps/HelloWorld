package com.Test.Domain;

import com.fasterxml.jackson.annotation.*;
import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Builder
@Entity
@Table(name = "customers")
@Getter
@Setter
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;

    /*public Customer(){

    }

    public Customer(long id, String name){
        super();
        this.id = id;
        this.name = name;

    }*/

    public Customer(){

    }

    public Customer(long id, String name) {
        super();
        this.id = id;
        this.name = name;
    }

    public Customer(long id, String name, Set<PhoneNumber> phoneNumber) {
        super();
        this.id = id;
        this.name = name;
        this.phoneNumbers = phoneNumber;
    }

   @ManyToMany(cascade = CascadeType.ALL)
   @JoinTable(name = "customers_phones", joinColumns = @JoinColumn(name = "customers_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "phone_numbers_id", referencedColumnName = "id"))
   @JsonIgnoreProperties("customers_phones")
   //@JoinTable(name="customers_phones")
   //@JsonManagedReference
   //@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    private Set<PhoneNumber> phoneNumbers;
}
