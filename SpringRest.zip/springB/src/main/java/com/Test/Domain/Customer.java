package com.Test.Domain;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "customers")
@Getter
@Setter
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String name;

    /*public Customer(){

    }

    public Customer(long id, String name){
        super();
        this.id = id;
        this.name = name;

    }*/

    public Customer(){

    }

    public Customer(long id, String name) {
        super();
        this.id = id;
        this.name = name;
    }

   @ManyToMany(cascade = CascadeType.ALL)
   @JoinTable(name = "customers_phones", joinColumns = @JoinColumn(name = "customers_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "phone_numbers_id", referencedColumnName = "id"))
   @JsonIgnoreProperties("customers_phones")
   //@JoinTable(name="customers_phones")
   //@JsonManagedReference
   //@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    private Set<PhoneNumber> phoneNumbers;
}
