package com.Test.Domain.Controller;

import java.io.*;
import java.util.*;
import com.Test.Domain.Item;
import com.Test.Domain.Order;
import lombok.Builder;
import lombok.ToString;
import com.Test.Domain.Customer;
import com.Test.Domain.Service.OrderService;
import name.falgout.jeffrey.testing.junit.mockito.MockitoExtension;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.web.JsonPath;
import org.springframework.http.HttpHeaders;
//import org.springframework.mock.web.MockHtppServletResponse;
import static org.hamcrest.Matchers.equalTo;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.Map;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestExecutionListeners;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.support.DependencyInjectionTestExecutionListener;
import org.springframework.test.context.support.DirtiesContextTestExecutionListener;
import org.springframework.test.context.transaction.TransactionalTestExecutionListener;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.*;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


import static org.junit.Assert.*;

@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class OrderControllerTest {


    @Mock
    private OrderService orderService;

    @InjectMocks
    private OrderController ordController;

    private MockMvc mockMvc;


    @BeforeEach
    public void setUp() throws Exception {
        mockMvc= MockMvcBuilders.standaloneSetup(ordController)
                .build();
    }

    @Test
    public void testGetOrders() throws Exception {

        Customer cust = Customer.builder().build();
        Item item = Item.builder().build();
        List<Item> itemList = new ArrayList<Item>();
        itemList.add(item);


        Order order =Order.builder().Id(1).items(itemList).customer(cust).createdAt(new Date()).build();
        when(orderService.getOrderById(1)).thenReturn( Optional.of(order));


        mockMvc.perform(MockMvcRequestBuilders.get("/customers/{customerId}/orders/{id}",3))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(jsonPath("$.id", equalTo(1)))
                //.andExpect(jsonPath("$.description", is("Lorem ipsum")))
                //.andExpect(jsonPath("$.title", is("Foo")));
                .andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE));
    }

    @Test
    public void return201WhenCreatingOrder() {
        int Orderid = 3;

        when(orderService.addOrder();)
    }

    @Test
    public void addOrder() {
    }

    @Test
    public void updateOrder() {
    }

    @Test
    public void deleteOrder() {
    }
}