SET FOREIGN_KEY_CHECKS = 0;
truncate table items;
truncate table customers_phones;
truncate table orders;
truncate table phone_numbers;
truncate table customers;
truncate table products;
SET FOREIGN_KEY_CHECKS = 1;