package com.Test.Domain.Repository;

import com.Test.Domain.Customer;
import com.Test.Domain.Order;
import org.springframework.data.repository.CrudRepository;

public interface OrderRepository extends CrudRepository<Order,Long> {

    Order findByCustomer(Customer customer);
}