package com.Test.Domain.Service;

import com.Test.Domain.Customer;
import com.Test.Domain.Repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {
    @Autowired
    @Qualifier("fakeData")
    private CustomerRepository custRepo;

    public List<Customer> getAllCustomers(){
        List<Customer> customers = new ArrayList<>();
        custRepo.findAll().forEach(customers::add);
        return customers;
    }

    public Optional<Customer> getStudentById(long Id){
        return custRepo.findById(Id);
    }

    public void removeStudentById(long id) {
        this.custRepo.deleteById(id);
    }

//    public void updateStudent(Customer student) {
//        this.custRepo.updateStudent(student);
//    }

    public void addCustomer(Customer cust) {
        custRepo.save(cust);
    }
}


