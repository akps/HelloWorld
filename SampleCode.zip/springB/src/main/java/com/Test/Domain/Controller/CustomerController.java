package com.Test.Domain.Controller;


import com.Test.Domain.Customer;
import com.Test.Domain.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/customers")
public class CustomerController {


    @Autowired
    private CustomerService custService;

    @RequestMapping(method = RequestMethod.GET)
    public Iterable<Customer> getAllStudents(){
        return custService.getAllCustomers();
    }
/*

    @RequestMapping(value = "/{id}" ,method = RequestMethod.GET)
    public Student getStudentById(@PathVariable("id") int id){
        return studentService.getStudentById(id);
    }

    @RequestMapping(value = "/{id}" ,method = RequestMethod.DELETE)
    public void deleteStudentById(@PathVariable("id") int id){
        studentService.removeStudentById(id);
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE )
    public void updateStudent(@RequestBody Student student){
        studentService.updateStudent(student);
    }

*/

    @RequestMapping(method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE )
    public void addCustomer(@RequestBody Customer cust){
        custService.addCustomer(cust);
    }


}
